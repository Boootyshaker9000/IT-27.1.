public class Zakaznik extends Osoba{
    private int cislo_zakaznicke_karty;

    public Zakaznik(String jmeno, String prijmeni, int cislo_zakaznicke_karty) {
        super(jmeno, prijmeni);
        this.cislo_zakaznicke_karty = cislo_zakaznicke_karty;
    }

    public int getCislo_zakaznicke_karty() {
        return cislo_zakaznicke_karty;
    }

    public void setCislo_zakaznicke_karty(int cislo_zakaznicke_karty) {
        this.cislo_zakaznicke_karty = cislo_zakaznicke_karty;
    }

    @Override
    public String toString() {
        return "Zakaznik{" +
                "cislo_zakaznicke_karty=" + cislo_zakaznicke_karty +
                ", jmeno='" + jmeno + '\'' +
                ", prijmeni='" + prijmeni + '\'' +
                '}';
    }
}
