public class AlkoholickyNapoj extends Napoj{
    private double procento_alkoholu;

    public AlkoholickyNapoj(int cena, String nazev, double procento_alkoholu) {
        super(cena, nazev);
        this.procento_alkoholu = procento_alkoholu;
    }

    public double getProcento_alkoholu() {
        return procento_alkoholu;
    }

    public void setProcento_alkoholu(double procento_alkoholu) {
        this.procento_alkoholu = procento_alkoholu;
    }

    @Override
    public String toString() {
        return "AlkoholickyNapoj{" +
                "procento_alkoholu=" + procento_alkoholu +
                ", cena=" + cena +
                ", nazev='" + nazev + '\'' +
                '}';
    }
}
