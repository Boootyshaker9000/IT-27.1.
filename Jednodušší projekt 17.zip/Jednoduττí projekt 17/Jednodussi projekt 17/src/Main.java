public class Main {

    public static void main(String[] args) {
        System.out.println("Hello world!");

        Napoj piti = new Napoj(15, "čaj");
        AlkoholickyNapoj chlast = new AlkoholickyNapoj(30, "pivo", 4.0);
        System.out.println(piti.toString());
        System.out.println(chlast.toString());

        System.out.println();

        Zamestnanec pracovnik = new Zamestnanec("Josef", "Kostrbatý", 1300);
        System.out.println(pracovnik.toString());
        System.out.println("nový plat"+pracovnik.zvysPlat());
        Zakaznik zakaznik = new Zakaznik("Alfons", "Nový", 165);
        System.out.println(zakaznik.toString());

        Osoba osoba1 = new Zamestnanec("Karel","Novak",25000);
        System.out.println(osoba1);
//        osoba1.zvysPlat();

        Osoba osoba2 = new Zakaznik("Jan","Cerny",15322);
        System.out.println(osoba2);

//        Zamestnanec osoba3 = new Osoba("Dan", "Modry");
//        System.out.println(osoba3);

        System.out.println();

        Zvire[] zvires = new Zvire[]{new Pes(35.4, 7, "vlcak"), new Pes(15, 3, "samojed"), new Kocka(4.5, 4, "Micka"), new Kocka(3, 2, "Mourek"), new Pes(45.3, 4, "tibetská doga"), new Pes(18, 6, "kolie"), new Kocka(2.8, 3, "Liza"), new Pes(20, 10, "dalmatin")};

        for (int i = 0; i < zvires.length; i++){
            System.out.println(zvires[i].toString());
            System.out.println(zvires[i].vydejZvuk());
            System.out.println();
        }

        int n = 0;
        for (int i = 0; i < zvires.length; i++){
            if (zvires[i] instanceof Pes){
                if (((Pes) zvires[i]).getRasa_psa().equals("dalmatin")){
                    n++;
                }
            }
        }
        System.out.println("Pocet dalmatinů je "+n);
        System.out.println();

        int nejmladsi_vek = Integer.MAX_VALUE;
        for (int i = 0; i < zvires.length; i++){
            if (zvires[i].vek<nejmladsi_vek){
                nejmladsi_vek=zvires[i].vek;
            }
        }

        for (int i = 0; i < zvires.length; i++){
            if (zvires[i].vek == nejmladsi_vek){
                System.out.println("Nejmladší věk má zvíře "+zvires[i].toString());
            }
        }
    }
}