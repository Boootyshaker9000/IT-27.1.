public class Kocka extends Zvire{
    private String jmeno;

    public Kocka(double hmotnost, int vek, String jmeno) {
        super(hmotnost, vek);
        this.jmeno = jmeno;
    }

    public String getJmeno() {
        return jmeno;
    }

    public void setJmeno(String jmeno) {
        this.jmeno = jmeno;
    }

    public String vydejZvuk(){
        return "Mnau, mnau";
    }

    @Override
    public String toString() {
        return "Kocka{" +
                "jmeno='" + jmeno + '\'' +
                ", hmotnost=" + hmotnost +
                ", vek=" + vek +
                '}';
    }
}