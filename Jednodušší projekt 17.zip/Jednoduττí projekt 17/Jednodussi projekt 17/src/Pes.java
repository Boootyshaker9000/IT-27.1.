public class Pes extends Zvire{
    private String rasa_psa;

    public Pes(double hmotnost, int vek, String rasa_psa) {
        super(hmotnost, vek);
        this.rasa_psa = rasa_psa;
    }

    public String getRasa_psa() {
        return rasa_psa;
    }

    public void setRasa_psa(String rasa_psa) {
        this.rasa_psa = rasa_psa;
    }

    public String vydejZvuk(){
        return "Vrrr, haf, haf";
    }

    @Override
    public String toString() {
        return "Pes{" +
                "rasa_psa='" + rasa_psa + '\'' +
                ", hmotnost=" + hmotnost +
                ", vek=" + vek +
                '}';
    }
}