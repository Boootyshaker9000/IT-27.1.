public class Zamestnanec extends Osoba{
    private int plat;

    public Zamestnanec(String jmeno, String prijmeni, int plat) {
        super(jmeno, prijmeni);
        this.plat = plat;
    }

    public int getPlat() {
        return plat;
    }

    public void setPlat(int plat) {
        this.plat = plat;
    }

    public int zvysPlat(){
        return getPlat()+2500;
    }

    @Override
    public String toString() {
        return "Zamestnanec{" +
                "plat=" + plat +
                ", jmeno='" + jmeno + '\'' +
                ", prijmeni='" + prijmeni + '\'' +
                '}';
    }
}