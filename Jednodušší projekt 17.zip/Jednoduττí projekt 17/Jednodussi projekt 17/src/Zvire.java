public class Zvire {
    protected double hmotnost;
    protected int vek;

    public Zvire(double hmotnost, int vek) {
        this.hmotnost = hmotnost;
        this.vek = vek;
    }

    public double getHmotnost() {
        return hmotnost;
    }

    public void setHmotnost(double hmotnost) {
        this.hmotnost = hmotnost;
    }

    public int getVek() {
        return vek;
    }

    public void setVek(int vek) {
        this.vek = vek;
    }

    public String vydejZvuk(){
        return "Vrrr";
    }

    @Override
    public String toString() {
        return "Zvire{" +
                "hmotnost=" + hmotnost +
                ", vek=" + vek +
                '}';
    }
}