public class Napoj {
    protected int cena;
    protected String nazev;

    public Napoj(int cena, String nazev) {
        this.cena = cena;
        this.nazev = nazev;
    }

    public int getCena() {
        return cena;
    }

    public void setCena(int cena) {
        this.cena = cena;
    }

    public String getNazev() {
        return nazev;
    }

    public void setNazev(String nazev) {
        this.nazev = nazev;
    }

    @Override
    public String toString() {
        return "Napoj{" +
                "cena=" + cena +
                ", nazev='" + nazev + '\'' +
                '}';
    }
}
